# Consistent Icons

Consistent Icons is a GNOME Shell extension that gives application icons a more uniform shape in the app grid, folder previews, search results, and compatible docks. It uses each icon supplied by GNOME or the active icon theme; it does not replace the system icon theme or change icons inside application windows.

Maintained by **DIOR27**.

## Appearance

The extension inspects the effective image used for an icon, including icons resolved from the currently active icon theme at the icon's display size and scale, then classifies its visible silhouette. It avoids forcing small raster sources to a larger intermediate size.

- Icons keep the full size assigned by GNOME. Rounded-square icons retain their existing artwork and corners; sharp-square icons retain their artwork and receive rounded corners.
- Other shapes are placed on a rounded tile that fills the same assigned size, with their artwork centered and scaled proportionally to 70% of the tile.

Shape detection uses the image's visible pixel bounds, transparency, and sampled edges and corners. It is a visual heuristic, so unusual artwork can be classified imperfectly. When an icon cannot be inspected, the extension uses the rounded-tile treatment as a fallback.

Generated tiles use light or dark colors to match GNOME's appearance setting. A subtle highlight and shadow add depth. The tile colors update when the system appearance changes, and icon analysis is refreshed when the active icon theme changes.

## Compatibility

The extension supports GNOME Shell 48, 49, and 50 from one package. It styles application icons created through GNOME Shell's shared app-icon API and refreshes existing actors it can identify. This also covers docks that use that API or expose an application and its icon actor to GNOME Shell. A third-party dock with a separate icon-rendering implementation may need its own integration.

## Install

Install the packaged extension from this directory:

```sh
gnome-extensions install consistent-icons@dior27.dev.shell-extension.zip
```

Then enable **Consistent Icons** in the Extensions app. If GNOME Shell does not discover it immediately, sign out and back in.

To package the current source, compile its settings schema and include both the XML and compiled form:

```sh
glib-compile-schemas --strict schemas
gnome-extensions pack --schema=schemas/org.gnome.shell.extensions.consistent-icons.gschema.xml --schema=schemas/gschemas.compiled .
```

The source is licensed under GNU GPL version 2 only. See [LICENSE](LICENSE).

## Preferences

Open **Consistent Icons** in GNOME Extensions to choose the tile background:

- **System** follows GNOME's light or dark appearance by default; choose light or dark explicitly to override it for the tile background.
- **Static color** uses GNOME's accent color or a color you select.
- **Gradient** can use the app icon or the active wallpaper as its color source. Wallpaper colors are read from GNOME's light or dark wallpaper URI according to the active appearance. If the wallpaper cannot be read, icon colors are used instead. Icon-based gradients use at most two dominant visible colors and build lighter and darker tones from them. Colors within 2 percentage points of the leader are treated as co-dominant; a tie between exactly two colors keeps both, while a tie between three or more keeps only the first color by hue. Linear and wave styles have eight directions; radial gradients can use the center or one of eight nearby focal points.

Changes apply to existing icons immediately. Background options affect only icons that receive a tile under the shape rules above.
